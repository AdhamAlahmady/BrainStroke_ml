document.getElementById("patient-form").addEventListener("submit", function(event){
    event.preventDefault();
    var form_data = new FormData(this);
    
    fetch("/classify", {
        method: 'POST',
        body: form_data
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("result").innerHTML = data.result;
    })
    .catch(error => console.error('Error:', error));
});

